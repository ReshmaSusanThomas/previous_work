from django.http import HttpResponse
from django.shortcuts import render
from django.core.mail import send_mail

from SIGNIN.models import Fund 

# Create your views here.
#def webapp_create(request):
	#return HttpResponse()

#def webapp_detail(request): #retrieve
#	return HttpResponse("<h1>detail</h1>")

def homepage(request):    #list items
	req = Fund.objects.all()[:6]
	context={
		'flag':False,
		'funds':req
	}
	if request.session.get('loggedin') == True:
		context['flag'] = True
	return render(request,"index.html",context)


def testmail(request):
	send_mail('Subject here', 'test','vcare.nss.mec@gmail.com',['ashwinkailas.mec@gmail.com'], fail_silently=False)
	return HttpResponse("sent mail")

#ef webapp_delete(request):
#	return HttpResponse("<h1>delete</h1>")

#from django.core.mail import send_mail
#end_mail('Subject here', 'Here is the message.', 'from@example.com', ['to@example.com'], fail_silently=False)
