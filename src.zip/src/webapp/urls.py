from django.conf.urls import url
from django.contrib import admin
from webapp.views import (
	homepage
	)

urlpatterns = [
	url(r'^$',homepage)
   ]
