from django.shortcuts import render,redirect
from .models import SIGNUP

# Create your views here.
def sign_up(request):
	if request.method == 'GET':
		return render(request,"signup.html",{})
	else:
		signup = SIGNUP(Name=request.POST['name'],
			Subname=request.POST['subname'],
			Address=request.POST['address'],
			Phone_Number= request.POST['telno'],
			E_mail= request.POST['email'],
			Password= request.POST['password']) 	
		signup.save()
		return redirect('/')
	