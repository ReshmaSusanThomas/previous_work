from django.conf.urls import url
from django.contrib import admin
from .views import (
sign_in,
logout,
Post
	)

urlpatterns = [
	url(r'logout/$',logout),
	url(r'post/$',Post),
	url(r'$',sign_in)
]
