from django.shortcuts import render,redirect

from SIGNUP.models import SIGNUP
from SIGNIN.models import Fund
from django.http import HttpResponse,JsonResponse

# Create your views here.

def sign_in(request):
	if request.method == 'GET':
		return render(request,"signin.html",{})
	else:
		print request.POST
		results = SIGNUP.objects.filter(E_mail=request.POST['username'])
		print results
		if len(results)!=0:
			if(results[0].Password!=request.POST['password']):
				return render(request,"signin.html",{'message':True})
			else:
				request.session['loggedin'] = True
				return redirect('/')
		return render(request,"signin.html",{'message':True})

def logout(request):
	request.session['loggedin'] = False
	return redirect('/')


# post
def Post(request):
	print request.POST
	if request.method == 'GET':
		return render(request,'start_fund.html',{})
	else:
		fund = Fund(Firstname=request.POST['firstname'],
			Lastname=request.POST['lastname'],
			Address=request.POST['address'],
			Phone_Number= request.POST['phoneno'],
			E_mail= request.POST['emailid'],
			Fundraiserheading= request.POST['fundraiser'],
			Fundraiserdetails= request.POST['fundraiserdetails'])
		fund.save()
		return JsonResponse({'status':True})
